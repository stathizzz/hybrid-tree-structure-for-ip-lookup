
/*
   Nexthop.h

   IP Lookup Using Level-Compressed Dynamic Tries. 
      
   The code presented in this file has been tested with care but is
   not guaranteed for any purpose. The writer does not offer any
   warranties nor does he accept any liabilities with respect to
   the code.

   Sfikas Efstathios , 15 January 2005.

   Computer Engineering and Informatics Department 
   Patras University of Patras 
   sfikas@ceid.upatras.gr


   Nexthop table functions and declarations
*/

#include <iostream.h>

typedef unsigned int word;	  

word nexthoptable[255];
int TABLESIZE = sizeof(nexthoptable)/sizeof(nexthoptable[0]);

word insertNHtable(word NHtable[], word next_hop)
{
	int c;
	for (c = 1; c <= TABLESIZE ; c++)
	{
		//we leave NHtable[0] so as not to collide with the value 
		//returned to indicate error (or table full)
		if (next_hop == NHtable[c])   
			return c;                 
                                       
		if (NHtable[c] == 0) 
		{
			NHtable[c] = next_hop;
	        return c;
		}
	}
	return 0;

};

 
word findpointer( word next_hop, word nexthoptable[])
{
	int c;
	for (c = 1 ; c < TABLESIZE; c++)
	{
		if (next_hop == nexthoptable[c]) 
			return c;
	}
	return 0;

}

